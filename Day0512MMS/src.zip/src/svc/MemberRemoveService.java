package svc;

public class MemberRemoveService {

	public boolean removeMember(String removeMemberId) {
		// TODO Auto-generated method stub
		boolean removeSccuess = false;
		
		
		
		return removeSccuess;
	}
	
}
